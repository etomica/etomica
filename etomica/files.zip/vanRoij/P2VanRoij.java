package vanRoij;

import etomica.*;

/**
 * The van Roij potential, which applies to two-site molecules.
 * The potential is -epsilon if site A of one molecule overlaps
 * site B of the other, and is zero otherwise.  Formation of multiple
 * overlaps of a site with more than one partner is prohibited (potential
 * is infinited for sites that overlap a site already overlapping another).
 * Two molecules cannot form mutual overlaps of both their sites (no
 * two-member rings).
 *
 * @author David Kofke
 */

public class P2VanRoij extends Potential2Group {
    
    private double sigma, epsilon;
    private PotentialVanRoij potential;
    
    public P2VanRoij() {
        super();
        potential = new PotentialVanRoij(this);
        addPotential(potential);
        sigma = Default.ATOM_SIZE;
        epsilon = 100.*Default.POTENTIAL_WELL;
    }
    
    public PotentialVanRoij potential() {return potential;}
    
    /**
     * Potential between the atoms of a van Roij molecule.
     */
    public class PotentialVanRoij extends Potential2 implements etomica.association.AssociationDefinition {
        
        final AtomPair pair;
        private int index;
        public PotentialVanRoij(PotentialGroup parent) {
            super(parent);
            pair = new AtomPair(parentSimulation().space());
        }
        public void setAssociationIndex(int idx) {index = idx;}
        
        public void calculate(IteratorDirective id, PotentialCalculation pc) {
            if( !(pc instanceof Potential2Calculation) ) return;
            iterator.reset(id);
            ((Potential2Calculation)pc).calculate(iterator, this); 
        }//end of calculate
    
        /**
         * Interatomic potential.  Given pair will always be atoms on 
         * separate molecules.
         */
        public double energy(AtomPair pair) {
            Atom a11 = pair.atom1;
            Atom a21 = pair.atom2;
            if(pair.r2() > sigma || a11.index() == a21.index()) return 0.0;
            
            Atom a12 = (a11.firstUpBond != null) ? 
                            a11.firstUpBond.bond.partner(a11) :
                            a11.firstDownBond.bond.partner(a11);
            Atom a22 = (a21.firstUpBond != null) ?
                            a21.firstUpBond.bond.partner(a21) :
                            a21.firstDownBond.bond.partner(a21);
            double energy = 0.0;
            switch(a11.atomList[index].size()) {
                case 0: return 0.0;
                case 1: if(a11.atomList[index].contains(a21)) {
                            if(a21.atomList[index].size()==1 && !a12.atomList[index].contains(a22)) return -epsilon;
                            else return Double.MAX_VALUE;
                        };
                default: return Double.MAX_VALUE;
            }
                            
                            
      /*      if(pair.r2() < sigma && a11.index() != a21.index()) {
                return -epsilon;
            } else {
                return 0.0;
            }*/
        }//end of energy
        
        public boolean isAssociated(Atom atom1, Atom atom2) {
            pair.reset(atom1, atom2);
            return (pair.r2() < sigma && atom1.index() != atom2.index());
   //         return energy(pair) == -epsilon;
        }
            
    }//end of PotentialVanRoij inner class
}//end of P2VanRoij