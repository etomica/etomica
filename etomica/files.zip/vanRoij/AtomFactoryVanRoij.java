package vanRoij;

import etomica.*;

/**
 * Atom factory for a van Roij molecule, which is composed of two atoms
 * connected by a bond.
 */
 
 public class AtomFactoryVanRoij extends AtomFactoryHomo {
    
    public AtomFactoryVanRoij(Space space) {
        this(space, Default.ATOM_SIZE);
    }
    
    /**
     * Constructor that takes bond length as a parameter, in addition to the space.
     */
    public AtomFactoryVanRoij(Space space, double d) {
        super(space, new AtomFactoryMono(space), 2, 
                new BondInitializerChain(), new ConfigurationLinear(space, d));
        AtomFactoryMono childFactory = (AtomFactoryMono)childFactory();
        childFactory.setType(new AtomType.Sphere(childFactory));
    }
    
    
    public static void main(String[] args) {
        Simulation sim = new Simulation(new Space2D());
        Simulation.instance = sim;
        Phase phase = new Phase(sim);
        AtomFactoryVanRoij factory = new AtomFactoryVanRoij(sim.space, 0.6*Default.ATOM_SIZE);
        P2VanRoij potential = new P2VanRoij();
        etomica.association.AssociationManager associationManager = 
            new etomica.association.AssociationManager(
                                new AtomIteratorSequential(),potential.potential());
        potential.potential().setAssociationIndex(associationManager.associationListIndex());
        sim.setEnergySum(associationManager.new EnergySum());
        Species species = new Species(sim,factory);
        DisplayPhase display = new DisplayPhase(sim);
        display.setColorScheme(new ColorSchemeVanRoij());
        potential.setSpecies(species, species);
        Controller controller = new Controller();
        IntegratorMC integrator = new IntegratorMC();
        integrator.addMCMoveListener(associationManager);
        integrator.setMCMoves(new MCMove[] {
            new MCMoveMolecule(integrator), new MCMoveRotate(integrator)});
        sim.elementCoordinator.go();
        Simulation.makeAndDisplayFrame(sim);
    }
 }