package vanRoij;

import etomica.*;
import java.awt.Color;

public class ColorSchemeVanRoij extends ColorScheme {
    
    public final void colorAtom(Atom a) {
        if(a.index() == 0) a.setColor(Color.red);
        else a.setColor(Color.blue);
    }
}
   